using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NavmeshUpdate : MonoBehaviour
{
   // public NavMeshSurface Surface2D;

    void Update()
    {
   //     Surface2D.UpdateNavMesh(Surface2D.navMeshData);
    }
}
